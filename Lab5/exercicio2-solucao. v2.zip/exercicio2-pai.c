/*-------------------------------------------------------------------------------------
| SO, Solucao do Exercicio 2, programa ESCRITOR PARALELO
|
| Autor: Joao Barreto
+-------------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------------
| includes
+-------------------------------------------------------------------------------------*/

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>

#define NUM_CHILDREN 10

#define DEFAULT_CHILD_EXEC_PATH "exercicio1-escritor"
#define CHILD_ARG0 "exercicio1-escritor"


/*-------------------------------------------------------------------------------------
| main
+-------------------------------------------------------------------------------------*/


pid_t child_pids[NUM_CHILDREN];


int main (int argc, char** argv) {

  pid_t pid;
  int runningChildren;
  char *childExecPath;

  struct timeval tvstart; /* start date */
  struct timeval tvend; /* end date */
  struct timeval tvduration; /* difference between both dates */
  unsigned int duration; /* difference between both dates in microseconds */

  time_t curtime; /* time in time_t format for format conversion */
  char buffer[30]; /* to write the date in a readable format */

  //We allow the pathname of the file to be executed by the child processes to 
  //be provided as a command line argument. If no argument is passed, we use a default pathname
  if (argc >=2)
    childExecPath = argv[1];
  else
    childExecPath = DEFAULT_CHILD_EXEC_PATH;

  if (gettimeofday(&tvstart, NULL) == -1) {
    perror("Could not get time of day, exiting.");
    exit(-1);
  }
  curtime=tvstart.tv_sec;
  strftime(buffer,30,"%m-%d-%Y  %T.",localtime(&curtime));
  printf("Start: %s%ld\n",buffer,tvstart.tv_usec);

  
  for (runningChildren = 0; runningChildren < NUM_CHILDREN; runningChildren++) {
    
    pid = fork();

    if (pid < 0) {
      perror("Could not fork a child.");
      exit(-1);
    } 
    else if (pid == 0) {
      if (execl(childExecPath, CHILD_ARG0, NULL) == -1) {
	perror("Could not execute child program.");
	exit(-1);
      }
      //Program should never reach this point
    }
  }
  
  int status;

  printf("Parent will now wait for the children to exit.\n");

  while (runningChildren > 0) {
    while ((pid=wait(&status)) == -1) ; //If wait is interrupted by signal, we try again
    printf("Child with pid=%ld completed with status 0x%x.\n", (long)pid, status);
    runningChildren --;
  }

  if (gettimeofday(&tvend, NULL) == -1) {
    perror("Could not get time of day, exiting.");
    exit(-1);
  }

  curtime=tvend.tv_sec;
  strftime(buffer,30,"%m-%d-%Y  %T.",localtime(&curtime));

  printf("End: %s%ld\n",buffer,tvend.tv_usec);

  tvduration.tv_sec = tvend.tv_sec - tvstart.tv_sec;
  tvduration.tv_usec = tvend.tv_usec - tvstart.tv_usec;
  duration = tvduration.tv_sec * 1000000 + tvduration.tv_usec;
  printf("Duration: %d microsseconds\n", duration);

}
