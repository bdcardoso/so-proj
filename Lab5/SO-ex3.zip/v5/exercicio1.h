#ifndef EXERCICIO1_H
#define EXERCICIO1_H

/*-------------------------------------------------------------------------------------
| constants
+-------------------------------------------------------------------------------------*/

#define NB_FILES       5  
#define NB_ENTRIES     1024
#define STRING_SZ      10

#define get_random(max) rand()%max

#endif /* EXERCICIO1_H */
