/*-------------------------------------------------------------------------------------
| SO, Solução do Exercício 1, programa ESCRITOR
|
| Autor: Luis Rodrigues
+-------------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------------
| includes
+-------------------------------------------------------------------------------------*/

#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#include "exercicio1.h"

/*-------------------------------------------------------------------------------------
| fixed strings
+-------------------------------------------------------------------------------------*/


char* myfiles[NB_FILES] = { "SO2014-0.txt", 
			    "SO2014-1.txt",
			    "SO2014-2.txt",
			    "SO2014-3.txt",
			    "SO2014-4.txt"};


/*-------------------------------------------------------------------------------------
| main
+-------------------------------------------------------------------------------------*/

int main (int argc, char** argv) {
  char  *file_to_open;
  int   fd;

  /* Initialize the seed of random number generator */
  srandom ((unsigned) time(NULL));

  file_to_open = myfiles[get_random(NB_FILES)];
  fd  = open (file_to_open, O_RDONLY);

  printf("Monitor will check if file %s is consistent...\n", file_to_open);

  if (fd == -1) {
    perror ("Error opening file");
    exit (-1);
  }
  else {
    char string_to_read[STRING_SZ];
    char first_string[STRING_SZ];
    int  i;

    if (read (fd, first_string, STRING_SZ) == -1) {
      perror ("Error reading file");
      exit (-1);
    }
    for (i=0; i<NB_ENTRIES-1; i++) {
      
      if (read (fd, string_to_read, STRING_SZ) == -1) {
		perror ("Error reading file");
		exit (-1);
      }

      if (strncmp(string_to_read, first_string, STRING_SZ)) {
		fprintf (stderr, "Inconsistent file: %s\n", file_to_open);
		exit (-1);
      }
    }
    if (close (fd) == -1)  {
      perror ("Error closing file");
      exit (-1);
    }
  }
  printf("YES.\n");
}
