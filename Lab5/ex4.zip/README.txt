- A solução do exercício 1 (leitor paralelo multiprocesso) encontra-se nos ficheiros:
  *** Código fonte ***	
	* exercicio4-pai.c
	* exercicio4-leitor.c
  *** Executáveis ***
	* exercicio4-pai
	* exercicio4-leitor

- A solução de exercício 2 (leitor paralelo multi-threaded + analise de ficheiros diferentes) encontra-se no ficheiro:
	* exercicio4-multithreaded.c (Código fonte)
	* exercicio4-multithreaded (Executável)

- A solução de exercício 3 (leitor paralelo multi-threaded + analise do mesmo ficheiro) encontra-se no ficheiro:
	* exercicio4-LEITOR-p3.c (Código fonte)
	* exercicio4-LEITOR-p3 (Executável)

- O ficheiro exercicio4-leitor-util.c contém funções comuns usadas em todos os exercícios

- Os headers files encontram-se na directoria include

