#ifndef EXERCICIO4_H
#define EXERCICIO4_H

/*-------------------------------------------------------------------------------------
| constants
+-------------------------------------------------------------------------------------*/

#define NUM_CHILDREN 3
#define NB_FILES       5  
#define NB_ENTRIES     1024
#define STRING_SZ      10
#define NB_STRINGS     10

#define get_random(max) rand()%max


#endif /* EXERCICIO2_H */
