#ifndef EXERCICIO4_LEITOR_H
#define EXERCICIO4_LEITOR_H


int reader(char  *file_to_open);
void* reader_wrapper(void* ptr);
void init_myfiles ();

#endif
